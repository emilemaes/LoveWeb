import supabase from './supabaseClient'

// Save data to Supabase
async function saveData() {
  const { data, error } = await supabase
    .from('your-table-name')
    .insert([{ key: 'key', value: 'value' }])

  if (error) {
    console.error('Error saving data:', error)
  } else {
    console.log('Data saved:', data)
  }
}

saveData()