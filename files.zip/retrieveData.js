import supabase from './supabaseClient'

// Retrieve data from Supabase
async function retrieveData() {
  const { data, error } = await supabase
    .from('your-table-name')
    .select('value')
    .eq('key', 'key')

  if (error) {
    console.error('Error retrieving data:', error)
  } else {
    console.log('Data retrieved:', data)
  }
}

retrieveData()